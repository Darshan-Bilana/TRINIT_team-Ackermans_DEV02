import React from "react";

export default function Home() {
  return (
    <>
      <div className="container my-3">
        <div className="mb-3">
          <h1>Welcome to SquashBugs!!</h1>
          <p></p>
          <h4>A site built for the sole purpose of squashing the bugs.</h4>
        </div>
        <p>Its simple to contribute to this community.</p>
        <p>
          Just SignUp and then Login...and then boom you are an offical
          SquashBug community member.
        </p>
        <h4>Some important Rules:</h4>
        <div className="accordion accordion-flush" id="accordionFlushExample">
          <div className="accordion-item">
            <h2 className="accordion-header" id="flush-headingOne">
              <button
                className="accordion-button collapsed"
                type="button"
                data-bs-toggle="collapse"
                data-bs-target="#flush-collapseOne"
                aria-expanded="false"
                aria-controls="flush-collapseOne"
              >
                #1
              </button>
            </h2>
            <div
              id="flush-collapseOne"
              className="accordion-collapse collapse"
              aria-labelledby="flush-headingOne"
              data-bs-parent="#accordionFlushExample"
            >
              <div className="accordion-body">
                Respect all members in this community, especially in discussion
                threads.
              </div>
            </div>
          </div>
          <div className="accordion-item">
            <h2 className="accordion-header" id="flush-headingTwo">
              <button
                className="accordion-button collapsed"
                type="button"
                data-bs-toggle="collapse"
                data-bs-target="#flush-collapseTwo"
                aria-expanded="false"
                aria-controls="flush-collapseTwo"
              >
                #2
              </button>
            </h2>
            <div
              id="flush-collapseTwo"
              className="accordion-collapse collapse"
              aria-labelledby="flush-headingTwo"
              data-bs-parent="#accordionFlushExample"
            >
              <div className="accordion-body">
                Remember that the members are of three types: Admin, Employee
                and User. Only Admin can Assign Employees or Users to particular
                RaiseBug query.
              </div>
            </div>
          </div>
          <div className="accordion-item">
            <h2 className="accordion-header" id="flush-headingThree">
              <button
                className="accordion-button collapsed"
                type="button"
                data-bs-toggle="collapse"
                data-bs-target="#flush-collapseThree"
                aria-expanded="false"
                aria-controls="flush-collapseThree"
              >
                #3
              </button>
            </h2>
            <div
              id="flush-collapseThree"
              className="accordion-collapse collapse"
              aria-labelledby="flush-headingThree"
              data-bs-parent="#accordionFlushExample"
            >
              <div className="accordion-body">
                Users are free to contribute in this community. They can raise
                bugs as well as resolve bugs. Remember the Admin keep an keen
                eye on all the users. You always have a chance to be recruited
                as an employee.
              </div>
            </div>
            <h4>Top contributers</h4>
          </div>
          
          <div className="card text-dark bg-grey">
            
            <div className="card-body">
              <h5 className="card-title">Erin</h5>
              
            </div>
          </div>
          <div className="card text-dark bg-grey">
            
            <div className="card-body">
              <h5 className="card-title">Levi</h5>
              
            </div>
          </div>
          <div className="card text-dark bg-grey">
            
            <div className="card-body">
              <h5 className="card-title">Armin</h5>
            
              
            
          </div>
        </div>
        
          
        </div>
      </div>
    </>
  );
}
