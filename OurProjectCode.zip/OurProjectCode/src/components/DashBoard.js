import React from "react";
export default function DashBoard() {
  return (
    <>
      <div className="container my-3">
        <div className="mb-3">
          <h1>DashBoard</h1>
        </div>

        <div className="card-group">
          <div className="card text-white bg-success mb-3">
            
            <div className="card-body">
              <h5 className="card-title">Bugs Solved</h5>
              <p className="card-text">
                35
              </p>
            </div>
          </div>
          <div className="card text-white bg-dark mb-3">
            
            <div className="card-body">
              <h5 className="card-title">Bugs Assigned</h5>
              <p className="card-text">
                15
              </p>
              
            </div>
          </div>
          <div className="card text-dark bg-warning mb-3">
            
            <div className="card-body">
              <h5 className="card-title">Bugs Remaining</h5>
              <p className="card-text">
                2
              </p>
              
            </div>
          </div>
        </div>
        <h4>Notifications</h4>
        <div className="list-group">
        <a href="/" className="list-group-item list-group-item-action" aria-current="true">
            <div className="d-flex w-100 justify-content-between">
            <h5 className="mb-1">Manobhav Commented</h5>
            <small>1 min ago</small>
            </div>
            <p className="mb-1">We have successfully submitted our website.</p>
            <small>Read more...</small>
        </a>
        <a href="/" className="list-group-item list-group-item-action">
            <div className="d-flex w-100 justify-content-between">
            <h5 className="mb-1">Ankit Commented</h5>
            <small className="text-muted">12 hours ago</small>
            </div>
            <p className="mb-1">We have started building our website.</p>
            <small className="text-muted">Read more...</small>
        </a>
        <a href="/" className="list-group-item list-group-item-action">
            <div className="d-flex w-100 justify-content-between">
            <h5 className="mb-1">Darshan commented</h5>
            <small className="text-muted">1 day ago</small>
            </div>
            <p className="mb-1">We are participating in Tri-Nit Hackathon.</p>
            <small className="text-muted">Read more...</small>
        </a>
        </div>
        
        <div className="input-group my-3">
        <select className="form-select" id="inputGroupSelect04" aria-label="Example select with button addon">
            <option selected>Search Bug by threat level...</option>
            <option value="1">Low</option>
            <option value="2">Medium</option>
            <option value="3">High</option>
        </select>
        <button className="btn btn-dark" type="button">Search</button>
        </div>
        <div className="card my-3">
        <ul className="list-group list-group-flush">
            <li className="list-group-item">Bug 0</li>
            <li className="list-group-item">Bug 1</li>
            <li className="list-group-item">Bug 2</li>
            <li className="list-group-item">Bug 3</li>
            <li className="list-group-item">Bug 4</li>
            <li className="list-group-item">Bug 5</li>
            <li className="list-group-item">Bug 6</li>
            <li className="list-group-item">Bug 7</li>
            <li className="list-group-item">Bug 8</li>
            <li className="list-group-item">Bug 9</li>
        
        </ul>
        </div>
      </div>
    </>
  );
}
