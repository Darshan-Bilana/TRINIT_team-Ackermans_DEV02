//import react from "react";
// Import the functions you need from the SDKs you need
// import { initializeApp } from "firebase/app";
// import { getAnalytics } from "firebase/analytics";
// import { getAuth, onAuthStateChanged } from "firebase/auth";

// const auth = getAuth();
// onAuthStateChanged(auth, (user) => {
//   if (user) {
//     // User is signed in, see docs for a list of available properties
//     // https://firebase.google.com/docs/reference/js/firebase.User
//     const uid = user.uid;
//     // ...
//   } else {
//     // User is signed out
//     // ...
//   }
// });

// // TODO: Add SDKs for Firebase products that you want to use
// // https://firebase.google.com/docs/web/setup#available-libraries

// // Your web app's Firebase configuration
// // For Firebase JS SDK v7.20.0 and later, measurementId is optional
// const firebaseConfig = {
//   apiKey: "AIzaSyCdD1jBn29Ld3A6AH083mqMN6boald77Jg",
//   authDomain: "signup-fb155.firebaseapp.com",
//   projectId: "signup-fb155",
//   storageBucket: "signup-fb155.appspot.com",
//   messagingSenderId: "229169371084",
//   appId: "1:229169371084:web:a2bb32d3189bcdeb10ef69",
//   measurementId: "G-LZKZ4X4K9M"
// };

// // Initialize Firebase
// const app = initializeApp(firebaseConfig);
// const analytics = getAnalytics(app);
export default function SignUp() {
    return(
        <div className="md-form md-outline input-with-post-icon datepicker" id="prefill">
            <input placeholder="Select date" type="text" id="prefill-example" className="form-control" />
            <label htmlFor="prefill-example">Try me...</label>
            <index className="fas fa-calendar input-prefix" tabIndex = "0"></index>
        </div>
        
    );
}