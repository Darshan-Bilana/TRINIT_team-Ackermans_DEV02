import "./App.css";
import Navbar from "./components/Navbar";
import Home from "./components/Home";
import RaiseBugs from "./components/RaiseBugs";
import ResolveBugs from "./components/ResolveBugs";
import RemoveBugs from "./components/RemoveBugs";
import SignUp from "./components/SignUp";
import DashBoard from "./components/DashBoard";
import About from "./components/About";
import Alert from "./components/Alert";
import { useState } from "react";
import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";

function App() {
  const [mode, setMode] = useState("dark");
  //whether darkMode is enabled or not
  const toggleMode = () => {
    if (mode === "light") {
      setMode("dark");
      showAlert("DarkMode has been enabled", "Success");
    } else {
      setMode("light");
      showAlert("DarkMode has been disAbled", "Success");
    }
  };
  const [alert, setAlert] = useState(null);
  const showAlert = (message, type) => {
    setAlert({
      msg: message,
      type: type,
    });
  };
  return (
    <>
      <Router>
        <Navbar title="SquashBugs" mode={mode} toggleMode={toggleMode} />
        <Alert alert={alert} />
        <Routes>
          <Route exact path="/Home" element={<Home />} />
          <Route exact path="/RaiseBugs" element={<RaiseBugs />} />
          <Route exact path="/ResolveBugs" element={<ResolveBugs />} />
          <Route exact path="/RemoveBugs" element={<RemoveBugs />} />
          <Route exact path="/DashBoard" element={<DashBoard />} />
          <Route exact path="/SignUP" element={<SignUp />} />
          <Route exact path="/About" element={<About />} />
        </Routes>
      </Router>
    </>
  );
}

export default App;
